//
//  Comment.swift
//  Made-App
//
//  Created by Chineye Emeghara on 10/22/20.
//

import Foundation

class Comment {
    
    var commentingUser = ""
    var commentText = ""
    
    init(commentingUser: String, commentText: String){
        
    }
    
}
