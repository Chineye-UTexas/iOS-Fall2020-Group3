//
//  Post.swift
//  Made-App
//
//  Created by Chineye Emeghara on 10/21/20.
//

import Foundation
import UIKit


//class Post {
//    
//    var title = ""
//    var category = ""
//    var description = ""
//    var instructions = ""
//    var unit = ""
//    var value = ""
//    var nameOfPoster = ""
//    var arrayOfImages: [UIImage] = []
//    
//    var postID = ""
//    var postImageURL = ""
//    var postCaption = ""
//    var postDate = "" //TODO change to date/time format
//    
//    init(title: String, category: String, description: String){
//        self.title = title
//        self.category = category
//        self.description = description
//    }
//    
//    init(post: Post){
//        self.title = post.title
//        self.arrayOfImages = post.arrayOfImages
//        self.category = post.category
//        self.description = post.description
//        self.instructions = post.instructions
//        self.postID = post.postID
//        self.postDate = post.postDate
//        self.postCaption = post.postCaption
//        self.nameOfPoster = post.nameOfPoster
//        self.unit = post.unit
//        self.value = post.value
//        self.postImageURL = post.postImageURL
//    }
//    
//}
