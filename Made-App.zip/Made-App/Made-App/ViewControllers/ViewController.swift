//
//  ViewController.swift
//  Made-App
//  Course: CS371L
//  Group 3
//
//  Created by Chineye Emeghara on 10/8/20.
//

import UIKit
import Alamofire

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

