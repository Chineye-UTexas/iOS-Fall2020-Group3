//
//  CommentReviewTableViewController.swift
//  Made-App
//
//  Created by Chineye Emeghara on 10/20/20.
//

import UIKit

class CommentReviewTableViewController: UITableView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
